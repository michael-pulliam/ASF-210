





list_data = [ 55 ,  31 ,  26 ,  20 ,  63 ,  7 ,  51 ,  74 ,  81 ,  40 ]

list_data.sort(key=None, reverse=False)

print(list_data)

